import { THIS_EXPR } from "@angular/compiler/src/output/output_ast";
import { EventEmitter, Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { Ingredient } from "../shared/ingredients.model";
import { ShoppingListService } from "../shopping-list/shopping-list.service";
import { Recipe } from "./recipe.model";

@Injectable()
export class RecipeService{
  // recipeSelected= new EventEmitter<Recipe>();
  // recipeSelected= new Subject<Recipe>();
  recipeChanged =new Subject<Recipe[]>();
  //  private recipes: Recipe[]=[
  //       new Recipe('A test','this is test recipe desc',
  //     'https://i.guim.co.uk/img/media/91d098d57084a3988b5c6c6008837a32d85f8237/104_0_2557_1831/master/2557.jpg?width=620&quality=45&auto=format&fit=max&dpr=2&s=91eded360a7ae18e0418b1b51454d40e',
  //     [new Ingredient('Banan',10)]),
  //     new Recipe('Another test','this is test recipe desc',
  //     'https://i.guim.co.uk/img/media/91d098d57084a3988b5c6c6008837a32d85f8237/104_0_2557_1831/master/2557.jpg?width=620&quality=45&auto=format&fit=max&dpr=2&s=91eded360a7ae18e0418b1b51454d40e',
  //     [new Ingredient('strawberry',50)]),
  //   ];
  private recipes:Recipe[]=[];
    constructor(private slService:ShoppingListService){}
    setRecipe(recipes:Recipe[]){
      this.recipes=recipes;
      this.recipeChanged.next(this.recipes.slice());
    }
    getRecipe(){
        return this.recipes.slice();
    }

    addIngredientsToShoppingList(ingredients:Ingredient[]){
    this.slService.addIngredients(ingredients);
    }
    
    getRecipes(index: number){
      return this.recipes[index];
    }
    addRecipe(recipe: Recipe){
      this.recipes.push(recipe);
      this.recipeChanged.next(this.recipes.slice());
    }
    updateRecipe(index:number,newRecipe: Recipe){
      this.recipes[index]=newRecipe;
      this.recipeChanged.next(this.recipes.slice());
    }
    onDeleteRecipe(index:number){
      this.recipes.splice(index,1);
      this.recipeChanged.next(this.recipes.slice());
    }
    
}
