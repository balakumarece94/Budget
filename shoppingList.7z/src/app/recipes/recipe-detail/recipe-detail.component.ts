import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Recipe } from '../recipe.model';
import { RecipeService } from '../recipe.service';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {
  recipe: Recipe;
  id: number;
  constructor(private rService:RecipeService,
    private route: ActivatedRoute,
    private router:Router) {

   }

  ngOnInit(): void {
    // const id=this.route.snapshot.params['id'];
    console.log("ngoninti recipe-details")
    this.route.params.subscribe(
      (params:Params)=>{
        this.id=+params['id'];
        console.log("id vlaues is:"+this.id);
        this.recipe=this.rService.getRecipes(this.id);
      }
    );
    
  }
  onAddToShoppingList(){
    this.rService.addIngredientsToShoppingList(this.recipe.ingredients);
  }
  onEdit(){
    this.router.navigate(['edit'],{relativeTo:this.route});
    // this.router.navigate(['../',this.id,'edit'],{relativeTo:this.route});
  }
  onDelete(){
    this.rService.onDeleteRecipe(this.id);
    this.router.navigate(['/recipes']);
  }

}
