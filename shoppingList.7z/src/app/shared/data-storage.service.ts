import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Recipe } from '../recipes/recipe.model';
import { RecipeService } from '../recipes/recipe.service';
import { exhaustMap, map,take,tap } from 'rxjs/operators';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class DataStorageService {
  constructor(private http:HttpClient,
      private rService:RecipeService,
      private authService:AuthService
      ) { }
  url='https://shopping-list-bk-default-rtdb.firebaseio.com/recipes.json';
  storeRecipes(){
  const recipe=this.rService.getRecipe();
    this.http.put(this.url,
    recipe).subscribe(
      Response=>{
        console.log(Response);
      }
    );
  }
  fetchRecipes(){
    
    return this.authService.user
      .pipe(
        take(1),
        exhaustMap(userData => {          
          return this.http.get<Recipe[]>(
            this.url+'?auth='+userData?.token
            // ,
            //  {
            //    params: new HttpParams().set('auth',userData?.token)
            //  }
            )
        }),
        map(recipes => {
          return recipes.map(recipe =>{
            return { 
              ...recipe,
              ingredients: recipe.ingredients ? recipe.ingredients: []
            };
          });
        }), 
        tap( (recipes:Recipe[])=>{
          this.rService.setRecipe(recipes);
        })
      );
    // return this.http.get<Recipe[]>(this.url)  
    // .pipe(
    //   map(recipes => {
    //     return recipes.map(recipe =>{
    //       return { 
    //         ...recipe,
    //         ingredients: recipe.ingredients ? recipe.ingredients: []
    //       };
    //     });
    //   }), 
    //   tap( (recipes:Recipe[])=>{
    //     this.rService.setRecipe(recipes);
    //   })

    // )
    // ;;;;;;;;;;;;;;;;;
    // )
    // .subscribe(
    //   recipes=>{
    //     console.log(recipes);
       
    //   }
    // );
  }

}
