import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EmailValidator } from '@angular/forms';
import { catchError,tap } from 'rxjs/operators';
import {BehaviorSubject, Subject, throwError } from 'rxjs';
import { User } from './user.model';
import { TypeScriptEmitter } from '@angular/compiler';
import { Router } from '@angular/router';

export interface AuthResponse{
  kind:string;
  idToken:string;
  email:string;
  refreshToken:string;
  expiresIn:string;
  localId:string;
  registered?:boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // user=new Subject<User>();
  user= new BehaviorSubject<User | null>(null);
  private tokeExpirationTimer:any;  
  constructor(private http:HttpClient,
    private router:Router) { }

  signUp(email:string, password: string){
    let url="https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyCoslAdgWZQrFqCpLDvsxm1WwUAnbNI6tw";
    return this.http.post<AuthResponse>(url,
      {
        email:email,
        password: password,
        returnSecureToken: true
      }
      ).pipe(
        catchError(this.handleError),
        tap(resData => {
          this.handleAuthentication(
            resData.email,
            resData.localId,
            resData.idToken,
            +resData.expiresIn
            );
        })
      );
  }

  login(email:string,password:string){
    let url="https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCoslAdgWZQrFqCpLDvsxm1WwUAnbNI6tw";
    return this.http.post<AuthResponse>(url,
      {
        email:email,
        password: password,
        returnSecureToken: true
      }).pipe(
        catchError(this.handleError),
        tap( resData => {
          this.handleAuthentication(
            resData.email,
            resData.localId,
            resData.idToken,
            +resData.expiresIn
            );
        })
      );

  }

private handleAuthentication(email:string,userId:string,token:string,expiresIn:number){
  const expirtationDate=new Date(new Date().getTime()+ +expiresIn*1000);
  const user=new User(
    email,
    userId,
    token,
    expirtationDate
    );
    this.user.next(user);
    this.autoLogout(expiresIn*1000);
    localStorage.setItem('userData',JSON.stringify(user));
}



  private handleError(errorRes: HttpErrorResponse){
    let errorMsg="Unknown error occuured!";
    if (!errorRes.error || !errorRes
      .error.error){
        return throwError(errorMsg);
      }
      console.log('error'+errorRes.error.error.message);
    switch (errorRes.error.error.message){
      case 'EMAIL_EXISTS':
          errorMsg="This email is exists already";
          break;
      case 'EMAIL_NOT_FOUND':
          errorMsg="This EMAIL_NOT_FOUND";
          break;
      case 'INVALID_PASSWORD':
          errorMsg="This INVALID_PASSWORD";
          break;
      }
      return throwError(errorMsg);
  }
  logout(){
    this.user.next(null);
    this.router.navigate(['/auth']);
    localStorage.removeItem('userData');
    if (this.tokeExpirationTimer){
      clearTimeout(this.tokeExpirationTimer);
    }
  }
  autoLogin(){
    const t=localStorage.getItem('userData');
    if (t===null){
      return;
    }
      const userData: {
        email: string;
        id: string;
        _token: string;
        _tokenExpirationDate: string;
      } = JSON.parse(t);;
    const loadUser= new User(
      userData.email,
      userData.id,
      userData._token,
      new Date(userData._tokenExpirationDate)
    );
    if (loadUser.token){
      this.user.next(loadUser);
      const exiprationDuraion=new Date(userData._tokenExpirationDate).getTime()-
      new Date().getTime();
      this.autoLogout(exiprationDuraion);
    }
  }

  autoLogout(expiratoinDuration: number){
    setTimeout(()=>{
      this.logout();
    },expiratoinDuration);
  }

}

