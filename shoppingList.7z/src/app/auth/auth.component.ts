import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService,AuthResponse } from './auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styles: []
})
export class AuthComponent implements OnInit {
  isLoginMode=true;
  error:string;
  constructor(private authService:AuthService,
    private router:Router
    ) { }

  
  ngOnInit(): void {
  }
  onSwitchMode(){
    this.isLoginMode=!this.isLoginMode;
  }
  onSubmit(form:NgForm){
    // console.log(form.value);
    if (!form.valid){
      return;
    }
    const email=form.value.email;
    const password=form.value.password;

    let authObs: Observable<AuthResponse>;

    if (this.isLoginMode){
      authObs=this.authService.login(email,password);
    }else{
      authObs=this.authService.signUp(email,password);
    }
    authObs.subscribe(
      resData => {
        console.log(resData);
        this.router.navigate(['/recipes']);
      },
      errorData => {
        console.log(errorData);
        this.error=errorData;
      }
    );
    form.reset();
  }


}


