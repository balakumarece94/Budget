import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BudgetService } from '../budget.service';
import { Budget } from '../model/Budget.model';

@Component({
  selector: 'app-budget',
  templateUrl: './budget.component.html',
  styleUrls: ['./budget.component.css']
})
export class BudgetComponent implements OnInit {
  constructor(private budgetService:BudgetService) { }
  products:Budget[];
  product:Budget;
  item:string;
  price:number;
  ngOnInit(): void {
    this.products=this.budgetService.products;
    console.log(this.products);
  }

  onClick(items:Budget,index:number){
  //  this.product=items;
   this.item=items.item;
   this.price=items.price;
    console.log(index+";"+items.item);
  }

  onSubmit(budget:Budget){
    this.budgetService.budgetItems.push(budget);
    
    // console.log(this.budgetService.budgetItems[1]);
  }

}
