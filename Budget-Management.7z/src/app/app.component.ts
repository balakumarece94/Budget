import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  title = 'Budget-Management';
  val="this is val";
  flag=false;
  twoWay="";
  parentData="";
  valFromChild="";
  @ViewChild("hightLight") marker:ElementRef;
  constructor(private router:Router){

  }
  test(){
      this.parentData=this.twoWay;
      console.log(this.parentData);

  }
  testEvent(val:any){
    console.log('event emiting='+val);
    this.valFromChild=val;
  }
  ngAfterViewInit(){
    console.log(this.marker);
    this.marker.nativeElement.style.color="yellow";
  }
}
