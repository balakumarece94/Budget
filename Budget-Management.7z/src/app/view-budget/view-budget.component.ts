import { Component, OnInit } from '@angular/core';
import { BudgetService } from '../budget.service';
import { Budget } from '../model/Budget.model';

@Component({
  selector: 'app-view-budget',
  templateUrl: './view-budget.component.html',
  styleUrls: ['./view-budget.component.css']
})
export class ViewBudgetComponent implements OnInit {
  budgets:Budget[];
  constructor(private budgetService:BudgetService) { }

  ngOnInit(): void {
    this.budgets=this.budgetService.budgetItems;
  }

}
