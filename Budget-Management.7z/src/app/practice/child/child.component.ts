import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input() parentData:String;
  @Output() testEvent=new EventEmitter<String>();
  constructor() { }

  ngOnInit(): void {
    this.testEvent.emit('hi bala event from child');
  }

}
