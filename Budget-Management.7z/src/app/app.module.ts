import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { BudgetComponent } from './budget/budget.component';
import { ViewBudgetComponent } from './view-budget/view-budget.component';
import { FormsModule } from '@angular/forms';
import { CustomDirective } from './practice/custom.directive';
import { ChildComponent } from './practice/child/child.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    BudgetComponent,
    ViewBudgetComponent,
    CustomDirective,
    ChildComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
