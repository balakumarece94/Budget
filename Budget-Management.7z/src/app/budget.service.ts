import { Injectable } from '@angular/core';
import { Budget } from './model/Budget.model';

@Injectable({
  providedIn: 'root'
})
export class BudgetService {
  public products:Budget[]=[{item:"Tea",price:12},{item:"Snacks",price:50}];
  public budgetItems:Budget[]=[];
  constructor() { 
    this.budgetItems.push({item:"Tea",price:12});

  }
}
