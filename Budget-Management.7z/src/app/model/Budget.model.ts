export class Budget{
    public item:string;
    public price:number;
}