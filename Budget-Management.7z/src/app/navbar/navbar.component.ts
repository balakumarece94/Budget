import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  date= new Date();
  constructor() {
    setInterval(() => {
      this.date = new Date();
    }, 1);
   }

  ngOnInit(): void {
  }
  displayDate(){
    // let latest_date;
  }

}
